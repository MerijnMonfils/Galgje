package controller;

public class Computer {

}
