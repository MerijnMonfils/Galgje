package view;

public class SpelGUI {

}
