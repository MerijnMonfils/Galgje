package view;

public class GalgGUI {

}
