package model;

public class Woordenlijst {

}
